import React, { useState } from 'react';
import {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableOpacity,
} from 'react-native';
import { firebase } from '../FireBase/FireBaseConfig';
import navigation from '@react-navigation/native';
import Signup from './Signup'

const Login = ({navigation}) =>{
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSignIn = () => {
    firebase
      .auth()
      .signInWithEmailAndPassword(email, password)
      .then(() => {
        navigation.navigate('Signup');
        alert('Signed in!!!');
      })

      .catch((error) => {
        alert('Failed!!!');
      });
  };

  return (
    <View style={styles.container}>
      <TextInput placeholder="E-mail" style={styles.input} />
      <TextInput placeholder="Password " style={styles.input} />
      <TouchableOpacity onPress={handleSignIn} style={styles.button}>
        Login
      </TouchableOpacity>

      <View style={styles.signupTextCont}>
        <Text style={styles.signupText}>Don't have an account?</Text>
        <TouchableOpacity
          onPress={() => {
            navigation.navigate('SignUp');
          }}>
          <Text> Sign up</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}
export default Login
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'white',
  },
  signupTextCont: {
    justifyContent: 'center',
    alignItems: 'flex-end',
    paddingVertical: 15,
    flexDirection: 'row',
  },

  input: {
    borderWidth: 1,
    borderColor: 'gray',
    height: 35,
    paddingLeft: 7,
    width: 250,
    marginTop: 10,
    borderRadius: 10,
  },
  signupText: {
    color: 'red',
    fontSize: 15,
  },
  button: {
    backgroundColor: '#cf34eb',
    height: 40,
    width: 150,
    textAlign: 'center',
    paddingTop: 12,
    color: 'white',
    marginTop: 10,
    borderRadius: 10,
    
  },
});
