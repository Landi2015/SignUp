import React, { useState } from 'react';
import {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableOpacity,
  AsyncStorage,
  Keyboard,
  Form,
} from 'react-native';
import { firebase } from '../FireBase/FireBaseConfig';

export default function Signup({navigation}) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [rePass, setRePass] = useState('');

  const handleSignIn = () => {
    {
      password === rePass
        ? firebase
            .auth()
            .createUserWithEmailAndPassword(email, password)
            .then(() => {
              navigation.navigate('Login');
              alert('Successfully Signed up!!!');
            })

            .catch((error) => {
              alert('Failed!!!');
            })
        : alert("Password don't match");
    }
  };

  return (
    <View style={styles.container}>
      <TextInput placeholder="Name" style={styles.input} />
      <TextInput placeholder="Surname " style={styles.input} />
      <TextInput
        placeholder="E-mail"
        style={styles.input}
        onChangeText={(Email) => {
          setEmail(Email);
        }}
      />
      <TextInput
        placeholder="Password "
        style={styles.input}
        onChangeText={(Password) => {
          setPassword(Password);
        }}
      />
      <TextInput
        placeholder="Confirm Password"
        style={styles.input}
        onChangeText={(rePass) => {
          setRePass(rePass);
        }}
      />
      <TouchableOpacity onPress={handleSignIn} style={styles.button}>
        Sign up
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'white',
  },

  input: {
    borderWidth: 1,
    borderColor: 'gray',
    height: 35,
    paddingLeft: 7,
    width: 250,
    marginTop: 10,
    borderRadius: 10,
  },
  signupText: {
    color: 'white',
    fontSize: 15,
  },
  button: {
    backgroundColor: '#cf34eb',
    height: 40,
    width: 150,
    textAlign: 'center',
    paddingTop: 12,
    color: 'white',
    marginTop: 10,
    borderRadius: 10,
  },
});
