import React from 'react';
import 'react-native-gesture-handler';
import navigation from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { StyleSheet, View, Text } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import StackNavigator from '@react-navigation/native';
import {firebase} from "./FireBase/FireBaseConfig";
import Login from './Screens/Login';
import Signup from './Screens/Signup';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
   
   <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Login" component={Login} /> 
        <Stack.Screen name="SignUp" component={Signup} />
      </Stack.Navigator>
    </NavigationContainer>
    
  );
}


