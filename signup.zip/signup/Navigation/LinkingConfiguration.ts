import Linking from 'expo-linking';
export default {
  prefixes: [Linking.makeUrl('/')],
  config: {
    screens: {
      LogIn: {
        screens: {
          SignUp: {
            screens: {
              SignUpScreen: 'one',
            },
          }, 
                
          NotFound: '*',
        },
      } 
    },
  }
}