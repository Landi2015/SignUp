import React from 'react';
import firebase from 'firebase';
import 'firebase/auth' ;
import 'firebase/firestore';


var firebaseConfig = {
    apiKey: "AIzaSyBsThsd-iVMNK-lzxC6ZXWmGu4Zx8_8nMs",
    authDomain: "signin-form-29c4e.firebaseapp.com",
    projectId: "signin-form-29c4e",
    storageBucket: "signin-form-29c4e.appspot.com",
    messagingSenderId: "2991515932",
    appId: "1:2991515932:web:3a56469d7a7196041732d9",
    measurementId: "G-CMXDJSYQQE"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);

  export {firebase}